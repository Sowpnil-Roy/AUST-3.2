package multipleproducerconsumerexample;    // Package of the code
import java.util.LinkedList;    // Importing LinkedList library
import java.util.Queue;    // Importing Queue library
import java.util.concurrent.locks.Condition;    // Importing Condition library
import java.util.concurrent.locks.Lock;    // Importing Lock library
import java.util.concurrent.locks.ReentrantLock;    // Importing ReentrantLock library

/**
 *
 * @author Sowpnil Roy (20200104071)
 */
public class MultipleProducerConsumerExample {   
    
    private static final int BUFFER_SIZE = 10;    // Constant to set buffer size
    private static Queue<Integer> buffer = new LinkedList<>();    // Creating buffer queue
    private static Lock lock = new ReentrantLock();    // Initialize lock object
    private static Condition bufferNotFull = lock.newCondition();    // Initialize condition object
    private static Condition bufferNotEmpty = lock.newCondition();    // Initialize condition object

    public static void main(String[] args) {    // main function
        int numProducers = 2;    // Initialize the number of producers
        int numConsumers = 2;    // Initialize the number of consumers

        for (int i = 1; i <= numProducers; i++) {    // for loop to create producer threads
            Thread producer = new Thread(new Producer(i));    // Create producer thread
            producer.start();    // Start producer thread
        }

        for (int i = 1; i <= numConsumers; i++) {    // for loop to create consumer threads
            Thread consumer = new Thread(new Consumer(i));    // Create consumer thread
            consumer.start();    // Start consumer thread
        }
    }

    static class Producer implements Runnable {    // Class definition
        private int id;

        public Producer(int id) {    // Constructor
            this.id = id;
        }

        @Override
        public void run() {    // run function
            try {
                while (true) {
                    lock.lock();    // Lock the lock object
                    try {
                        while (buffer.size() == BUFFER_SIZE) {    // Check if buffer is empty
                            // Buffer is full, wait for the buffer to have space
                            bufferNotFull.await();    // Wait for buffer to have space
                        }

                        int item = produceItem();    // Call the produceItem function
                        buffer.offer(item);    // Offer item to buffer
                        System.out.println("Producer " + id + " produced item: " + item);    // Print message on console

                        // Signal consumers that buffer is not empty
                        bufferNotEmpty.signalAll();    // Signal consumers that buffer is not empty
                    } finally {
                        lock.unlock();    // Unlock the lock object
                    }

                    Thread.sleep(1000);    // Sleep for 1 second
                }
            } catch (InterruptedException e) {
                e.printStackTrace();    // print stack trace
            }
        }

        private int produceItem() {    // ProduceItem function
            // Generate a random item
            return (int) (Math.random() * 100);    // Generate random number from 0 to 100
        }
    }

    static class Consumer implements Runnable {    // Class definition
        private int id;

        public Consumer(int id) {    // Constructor
            this.id = id;
        }

        @Override
        public void run() {    // run function
            try {
                while (true) {
                    lock.lock();    // Lock the lock object
                    try {
                        while (buffer.isEmpty()) {    // Check if buffer is empty
                            // Buffer is empty, wait for the buffer to have items
                            bufferNotEmpty.await();    // Wait for buffer to have item
                        }

                        int item = buffer.poll();    // Poll item from buffer
                        consumeItem(item);    // Call consumeItem function
                        System.out.println("Consumer " + id + " consumed item: " + item);    // Print message on console

                        // Signal producers that buffer is not full
                        bufferNotFull.signalAll();    // Signal producers that buffer is not full
                    } finally {
                        lock.unlock();    // Unlock the lock object
                    }

                    Thread.sleep(1000);    // Sleep for 1 second
                }
            } catch (InterruptedException e) {
                e.printStackTrace();    // print stack trace
            }
        }

        private void consumeItem(int item) {    // ConsumeItem function
            // Process the item
            System.out.println("Consumer " + id + " processed item: " + item);    // Print message on console
        }
    }
    
}
